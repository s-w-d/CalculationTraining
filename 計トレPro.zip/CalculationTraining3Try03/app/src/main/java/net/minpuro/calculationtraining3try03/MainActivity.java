package net.minpuro.calculationtraining3try03;

import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView textViewLevel;  //前の画面の難易度
    TextView textViewRemain;  //残り問題数
    TextView textViewCorrect;  //正解数
    TextView textViewPercent;  //正答率

    TextView textViewLeft;
    TextView textViewOperator;
    TextView textViewRight;
    TextView textViewAnswer;

    Button button0, button1, button2, button3, button4, button5,
            button6, button7, button8, button9, buttonMinus, buttonC,
            buttonDiv, buttonMul, buttonSub, buttonAdd;

    Button buttonAnswerCheck, buttonBack;

    ImageView imageViewAnswerCheck;
    TextView textViewLastMessage;
    TextView textViewComment;

    //ビュー以外のもの
    String questionLevel;  //前画面のレベル
    int selectQuestion;  //前画面の問題数

    int numberOfRemain;
    int numberOfCorrect;
    int numberOfPercent;

    int id;
    Random random;
    int questionOperator;  //符号
    int questionLeft;  //符号の左
    int questionRight;  //符号の右
    int questionAnswer;  //計算の答え

//    int numberOfLeft;  //符号の左
//    int numberOfRight;  //符号の右
//    int numberOfAnswer;  //右辺

    int questionPattern3;  //(中級)出題の3パターン
    int questionPattern4;  //「左」「符号」「右」「右辺」4パターン

    int myAnswerLeft;  //左を解答
//    int myAnswerOperator;  //符号を解答
    int myAnswerRight;  //右を解答
    int myAnswer;  //右辺を解答

    String strMyAnswerLeft;  //入力した左側
    String strMyAnswerOperator;  //入力した符号
    String strMyAnswerRight;  //入力した右側
    String strMyAnswer;  //入力した右辺

    int correctAnswerLeft;  //正解：符号の左
//    int correctAnswerOperator;  //正解：符号
    int correctAnswerRight;  //正解：符号の右
    int correctAnswer;  //正解：右辺
    int correctLeft;  //正解：左辺

    SoundPool soundPool;
    int soundCorrect, soundIncorrect;

    Timer timer;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewLevel = findViewById(R.id.textViewLevel);
        textViewRemain = findViewById(R.id.textViewRemain);
        textViewCorrect = findViewById(R.id.textViewCorrect);
        textViewPercent = findViewById(R.id.textViewPercent);

        textViewLeft = findViewById(R.id.textViewLeft);
        textViewOperator = findViewById(R.id.textViewOperator);
        textViewRight = findViewById(R.id.textViewRight);
        textViewAnswer = findViewById(R.id.textViewAnswer);

        button0 = findViewById(R.id.button0);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        buttonMinus = findViewById(R.id.buttonMinus);
        buttonC = findViewById(R.id.buttonC);
        buttonDiv = findViewById(R.id.buttonDiv);
        buttonMul = findViewById(R.id.buttonMul);
        buttonSub = findViewById(R.id.buttonSub);
        buttonAdd = findViewById(R.id.buttonAdd);

        buttonAnswerCheck = findViewById(R.id.buttonAnswerCheck);
        buttonBack = findViewById(R.id.buttonBack);

        imageViewAnswerCheck = findViewById(R.id.imageViewAnswerCheck);
        textViewLastMessage = findViewById(R.id.textViewLastMessage);
        textViewComment = findViewById(R.id.textViewComment);


        //クリックリスナー
        button0.setOnClickListener(this);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);
        buttonMinus.setOnClickListener(this);
        buttonC.setOnClickListener(this);
        buttonDiv.setOnClickListener(this);
        buttonMul.setOnClickListener(this);
        buttonSub.setOnClickListener(this);
        buttonAdd.setOnClickListener(this);
        buttonAnswerCheck.setOnClickListener(this);
        buttonBack.setOnClickListener(this);


        //インテントの受け取り
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        questionLevel = bundle.getString("keyLevel");
        selectQuestion = bundle.getInt("keySelect");


        //前で選んだ「問題数」表示
        numberOfRemain = selectQuestion;
        textViewRemain.setText(String.valueOf(numberOfRemain));

        //前に選んだ難易度の表示
        textViewLevel.setText(String.valueOf(questionLevel));

        random = new Random();
        questionPattern4 = random.nextInt(4) + 1;

        //「初級」「中級」「上級」で場合分けして出題
        if (questionLevel.equals("初級")) {
            elementaryQuestion();
        } else if (questionLevel.equals("中級")) {
            middleQuestion();
        } else if (questionLevel.equals("上級")) {
            advanceQuestion();
        }

    }

    @Override
    public void onResume() {
        super.onResume();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = new SoundPool.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build())
                    .setMaxStreams(1)
                    .build();
        } else {
            soundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        }

        soundCorrect = soundPool.load(this, R.raw.sound_correct, 1);
        soundIncorrect = soundPool.load(this, R.raw.sound_incorrect, 1);

        timer = new Timer();

    }

    @Override
    public void onPause() {
        super.onPause();
        soundPool.release();
    }

    private void elementaryQuestion() {
        button0.setEnabled(true);
        button1.setEnabled(true);
        button2.setEnabled(true);
        button3.setEnabled(true);
        button4.setEnabled(true);
        button5.setEnabled(true);
        button6.setEnabled(true);
        button7.setEnabled(true);
        button8.setEnabled(true);
        button9.setEnabled(true);
        buttonMinus.setEnabled(true);
        buttonC.setEnabled(true);
        buttonDiv.setEnabled(false);
        buttonMul.setEnabled(false);
        buttonSub.setEnabled(false);
        buttonAdd.setEnabled(false);

        buttonAnswerCheck.setEnabled(true);
        buttonBack.setEnabled(false);

        random = new Random();

        //2つの数字を1～100からランダムに出す。
        questionLeft = random.nextInt(100) + 1;  //1～100
        questionRight = random.nextInt(100) + 1;  //1～100

        textViewLeft.setText(String.valueOf(questionLeft));
        textViewRight.setText(String.valueOf(questionRight));

        //計算方法を「＋」「－」からランダムに出す。
        questionOperator = random.nextInt(2) + 1;
        switch (questionOperator) {
            case 1:
                textViewOperator.setText("+");
                break;
            case 2:
                textViewOperator.setText("-");
                break;
        }

        //前の問題で入力した自分の答えを消す。
        textViewAnswer.setText("");
        strMyAnswer = "";
        //〇・×画像を消す。
        imageViewAnswerCheck.setVisibility(View.INVISIBLE);

    }

    private void middleQuestion() {
        //中級を選んだとき
        button0.setEnabled(true);
        button1.setEnabled(true);
        button2.setEnabled(true);
        button3.setEnabled(true);
        button4.setEnabled(true);
        button5.setEnabled(true);
        button6.setEnabled(true);
        button7.setEnabled(true);
        button8.setEnabled(true);
        button9.setEnabled(true);
        buttonMinus.setEnabled(true);
        buttonC.setEnabled(true);
        buttonDiv.setEnabled(false);
        buttonMul.setEnabled(false);
        buttonSub.setEnabled(false);
        buttonAdd.setEnabled(false);
        buttonAnswerCheck.setEnabled(true);
        buttonBack.setEnabled(false);

        //「左」「右」「右辺」の出題3パターン
        questionPattern3 = random.nextInt(3) + 1;
        //符号「+」「-」「×」「÷」を出す4パターン
        questionOperator = random.nextInt(4) + 1;


        switch (questionPattern3) {
            case 1:  //符号の左を解答するとき
                textViewLeft.setText("");
                strMyAnswerLeft = "";

                switch (questionOperator) {
                    case 1:  //符号が＋なら
                        //TODO A-R=L
                        textViewOperator.setText("+");

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;
                        questionAnswer  = questionLeft + questionRight;

                        textViewRight.setText(String.valueOf(questionRight));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 2:  //符号が－なら
                        //TODO A+R=L
                        textViewOperator.setText("-");

                        questionRight = random.nextInt(1000) + 1;
                        questionLeft = random.nextInt(1000) + 1;
                        questionAnswer = questionLeft - questionRight;

                        textViewRight.setText(String.valueOf(questionRight));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 3:  //符号が×なら
                        //TODO A÷R=L
                        textViewOperator.setText("×");

                        questionRight = random.nextInt(100) + 1;

                        while (true) {
                            questionLeft = random.nextInt(1000) + 1;
                            questionAnswer = questionLeft * questionRight;

                            int divisionA_case1_3 = questionAnswer % questionRight;

                            if (divisionA_case1_3 == 0) {
                                textViewRight.setText(String.valueOf(questionRight));
                                textViewAnswer.setText(String.valueOf(questionAnswer));

                                break;
                            }
                        }
                        break;

                    case 4:  //符号が÷なら
                        //TODO A÷R=L
                        textViewOperator.setText("÷");

                        questionRight = random.nextInt(100) + 1;

                        while (true) {
                            questionLeft = random.nextInt(1000) + 1;

                            int sub_case1_4 = questionLeft - questionRight;
                            int div_case1_4 = (questionLeft / questionRight) % questionRight;

                            if (sub_case1_4 >= 1 && div_case1_4 == 0) {
                                questionAnswer = questionLeft / questionRight;

                                textViewRight.setText(String.valueOf(questionRight));
                                textViewAnswer.setText(String.valueOf(questionAnswer));

                                break;
                            }
                        }
                        break;

                }
                break;

            case 2:  //符号の右を解答するとき
                textViewRight.setText("");
                strMyAnswerRight = "";

                switch (questionOperator) {
                    case 1:  //符号が＋なら
                        //TODO A-L=R
                        textViewOperator.setText("+");

                        questionLeft = random.nextInt(1000) + 1;
                        questionAnswer = random.nextInt(1000) + 1;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 2:  //符号が－なら
                        //TODO L-A=R
                        textViewOperator.setText("-");

                        questionLeft = random.nextInt(1000) + 1;
                        questionAnswer = random.nextInt(1000) + 1;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 3:  //符号が×なら
                        //TODO R=A÷L
                        textViewOperator.setText("×");

                        questionLeft = random.nextInt(1000) + 1;

                        while (true) {
                            questionRight = random.nextInt(100) + 1;

                            int sub_case3_3 = questionLeft - questionRight;
                            int division_case3_3 = (questionLeft * questionRight) % questionLeft;

                            if (sub_case3_3 >= 1 && division_case3_3 == 0) {
                                questionAnswer = questionLeft / questionRight;

                                textViewAnswer.setText(String.valueOf(questionAnswer));
                                textViewLeft.setText(String.valueOf(questionLeft));

                                break;
                            }
                        }
                        break;

                    case 4:  //符号が÷なら
                        //TODO R=L÷A
                        textViewOperator.setText("÷");

                        questionRight = random.nextInt(100) + 1;

                        while (true) {
                            questionLeft = random.nextInt(1000) + 1;
                            int sub_case3_4 = questionLeft - questionRight;

                            if (sub_case3_4 >= 1) {
                                int division_case3_4 = questionLeft % (questionLeft / questionRight);

                                if (division_case3_4 == 0) {
                                    questionAnswer = questionLeft / questionRight;

                                    textViewLeft.setText(String.valueOf(questionLeft));
                                    textViewAnswer.setText(String.valueOf(questionAnswer));

                                    break;
                                }
                            }

                        }
                        break;

                }
                break;

            case 3:  //右辺を解答するとき
                textViewAnswer.setText("");
                strMyAnswer = "";

                switch (questionOperator) {
                    case 1:  //＋なら
                        //TODO L+R=A
                        textViewOperator.setText("+");

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewRight.setText(String.valueOf(questionRight));

                        break;

                    case 2:  //－なら
                        //TODO L-R=A
                        textViewOperator.setText("-");

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewRight.setText(String.valueOf(questionRight));

                        break;

                    case 3:  //×なら
                        //TODO L×R=A
                        textViewOperator.setText("×");

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewRight.setText(String.valueOf(questionRight));

                        break;

                    case 4:  //÷なら
                        //TODO L÷R=A
                        textViewOperator.setText("÷");

                        questionRight = random.nextInt(1000) + 1;

                        while (true) {
                            questionLeft = random.nextInt(1000);
                            questionAnswer = questionLeft - questionRight;

                            int sub_case4_4 = questionLeft - questionRight;
                            int division_case4_4 = questionLeft % questionRight;

                            if (sub_case4_4 >= 1 && division_case4_4 == 0) {
                                textViewLeft.setText(String.valueOf(questionLeft));
                                textViewRight.setText(String.valueOf(questionRight));

                                break;
                            }
                        }
                        break;

                }
                break;
        }

        imageViewAnswerCheck.setVisibility(View.INVISIBLE);

    }

    private void advanceQuestion() {
        //上級を選んだとき
        button0.setEnabled(true);
        button1.setEnabled(true);
        button2.setEnabled(true);
        button3.setEnabled(true);
        button4.setEnabled(true);
        button5.setEnabled(true);
        button6.setEnabled(true);
        button7.setEnabled(true);
        button8.setEnabled(true);
        button9.setEnabled(true);
        buttonMinus.setEnabled(true);
        buttonC.setEnabled(true);
        buttonDiv.setEnabled(true);
        buttonMul.setEnabled(true);
        buttonSub.setEnabled(true);
        buttonAdd.setEnabled(true);
        buttonAnswerCheck.setEnabled(true);
        buttonBack.setEnabled(false);

        //符号「+」「-」「×」「÷」4パターン
        questionOperator = random.nextInt(4) + 1;


        switch (questionPattern4) {
            case 1:  //符号の左を解答するとき
                textViewLeft.setText("");
                strMyAnswerLeft = "";

                switch (questionOperator) {
                    case 1:  //符号が＋なら
                        //TODO A-R=L
                        textViewOperator.setText("+");

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;
                        questionAnswer  = questionLeft + questionRight;

                        textViewRight.setText(String.valueOf(questionRight));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 2:  //符号が－なら
                        //TODO A+R=L
                        textViewOperator.setText("-");

                        questionRight = random.nextInt(1000) + 1;
                        questionLeft = random.nextInt(1000) + 1;
                        questionAnswer = questionLeft - questionRight;

                        textViewRight.setText(String.valueOf(questionRight));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 3:  //符号が×なら
                        //TODO A÷R=L
                        textViewOperator.setText("×");

                        questionRight = random.nextInt(1000) + 1;

                        while (true) {
                            questionLeft = random.nextInt(1000) + 1;
                            questionAnswer = questionLeft * questionRight;

                            int divisionA_case1_3 = questionAnswer % questionRight;

                            if (divisionA_case1_3 == 0) {
                                textViewRight.setText(String.valueOf(questionRight));
                                textViewAnswer.setText(String.valueOf(questionAnswer));

                                break;
                            }
                        }
                        break;

                    case 4:  //符号が÷なら
                        //TODO A÷R=L
                        textViewOperator.setText("÷");

                        questionRight = random.nextInt(1000) + 1;

                        while (true) {
                            questionLeft = random.nextInt(1000) + 1;
                            questionAnswer = questionLeft / questionRight;

                            int sub_case1_4 = questionLeft - questionRight;
                            int div_case1_4 = questionAnswer % questionRight;

                            if (sub_case1_4 >= 1 && div_case1_4 == 0) {
                                textViewRight.setText(String.valueOf(questionRight));
                                textViewAnswer.setText(String.valueOf(questionAnswer));

                                break;
                            }
                        }
                        break;

                }
                break;

            case 2:  //「符号」を解答するとき
                textViewOperator.setText("");
                strMyAnswerOperator = "";

                switch (questionOperator) {
                    case 1:  //＋なら

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;
                        questionAnswer = questionLeft + questionRight;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewRight.setText(String.valueOf(questionRight));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 2:  //－なら

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;
                        questionAnswer = questionLeft - questionRight;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewRight.setText(String.valueOf(questionRight));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 3:  //×なら

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;
                        questionAnswer = questionLeft * questionRight;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewRight.setText(String.valueOf(questionRight));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 4:  //÷なら

                        questionRight = random.nextInt(1000) + 1;

                        while (true) {
                            questionLeft = random.nextInt(1000) + 1;

                            int sub_case2_4 = questionLeft - questionRight;
                            int div_case2_4 = questionLeft % questionRight;

                            if (sub_case2_4 >= 1 && div_case2_4 == 0) {
                                questionAnswer = questionLeft / questionRight;

                                textViewLeft.setText(String.valueOf(questionLeft));
                                textViewRight.setText(String.valueOf(questionRight));
                                textViewAnswer.setText(String.valueOf(questionAnswer));

                                break;
                            }
                        }
                        break;

                }
                break;

            case 3:  //符号の右を解答するとき
                textViewRight.setText("");
                strMyAnswerRight = "";

                switch (questionOperator) {
                    case 1:  //符号が＋なら
                        //TODO A-L=R
                        textViewOperator.setText("+");

                        questionLeft = random.nextInt(1000) + 1;
                        questionAnswer = random.nextInt(1000) + 1;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 2:  //符号が－なら
                        //TODO L-A=R
                        textViewOperator.setText("-");

                        questionLeft = random.nextInt(1000) + 1;
                        questionAnswer = random.nextInt(1000) + 1;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewAnswer.setText(String.valueOf(questionAnswer));

                        break;

                    case 3:  //符号が×なら
                        //TODO A÷L=R
                        textViewOperator.setText("×");

                        questionLeft = random.nextInt(1000) + 1;

                        while (true) {
                            questionRight = random.nextInt(1000) + 1;
                            questionAnswer = questionLeft * questionRight;

                            int sub_case3_3 = questionLeft - questionRight;
                            int division_case3_3 = questionAnswer % questionLeft;

                            if (sub_case3_3 >= 1 && division_case3_3 == 0) {

                                textViewAnswer.setText(String.valueOf(questionAnswer));
                                textViewLeft.setText(String.valueOf(questionLeft));

                                break;
                            }
                        }
                        break;

                    case 4:  //符号が÷なら
                        //TODO R=L÷A
                        textViewOperator.setText("÷");
                        button0.setEnabled(false);

                        questionRight = random.nextInt(1000) + 1;

                        while (true) {
                            questionLeft = random.nextInt(1000) + 1;
                            int sub_case3_4 = questionLeft - questionRight;

                            if (sub_case3_4 >= 1) {
                                int division_case3_4 = questionLeft % (questionLeft / questionRight);

                                if (division_case3_4 == 0) {
                                    questionAnswer = questionLeft / questionRight;

                                    textViewLeft.setText(String.valueOf(questionLeft));
                                    textViewAnswer.setText(String.valueOf(questionAnswer));

                                    break;
                                }
                            }

                        }
                        break;

                }
                break;

            case 4:  //右辺を解答するとき
                textViewAnswer.setText("");
                strMyAnswer = "";

                switch (questionOperator) {
                    case 1:  //＋なら
                        //TODO L+R=A
                        textViewOperator.setText("+");

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewRight.setText(String.valueOf(questionRight));

                        break;

                    case 2:  //－なら
                        //TODO L-R=A
                        textViewOperator.setText("-");

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewRight.setText(String.valueOf(questionRight));

                        break;

                    case 3:  //×なら
                        //TODO L×R=A
                        textViewOperator.setText("×");

                        questionLeft = random.nextInt(1000) + 1;
                        questionRight = random.nextInt(1000) + 1;

                        textViewLeft.setText(String.valueOf(questionLeft));
                        textViewRight.setText(String.valueOf(questionRight));

                        break;

                    case 4:  //÷なら
                        //TODO L÷R=A
                        textViewOperator.setText("÷");

                        questionRight = random.nextInt(1000) + 1;

                        while (true) {
                            questionLeft = random.nextInt(1000) + 1;

                            int sub_case4_4 = questionLeft - questionRight;
                            int division_case4_4 = questionLeft % questionRight;

                            if (sub_case4_4 >= 1 && division_case4_4 == 0) {
                                textViewLeft.setText(String.valueOf(questionLeft));
                                textViewRight.setText(String.valueOf(questionRight));

                                break;
                            }
                        }
                        break;

                }
                break;
        }

        imageViewAnswerCheck.setVisibility(View.INVISIBLE);

    }

    @Override
    public void onClick(View v) {

        id = v.getId();

        if (questionLevel.equals("初級")) {
            switch (id) {
                case R.id.buttonAnswerCheck:
                    answerCheckElementary();
                    break;
                case R.id.buttonBack:
                    back();
                    break;
                default:
                    numberClickElementary(id);
                    break;
            }

        } else if (questionLevel.equals("中級")) {
            switch (id) {
                case R.id.buttonAnswerCheck:
                    answerCheckMiddle();
                    break;
                case R.id.buttonBack:
                    back();
                    break;
                default:
                    numberClickMiddle(id);
                    break;
            }

        } else if (questionLevel.equals("上級")) {
            switch (id) {
                case R.id.buttonAnswerCheck:
                    answerCheckAdvance();
                    break;
                case R.id.buttonBack:
                    back();
                    break;
                default:
                    numberClickAdvance(id);
                    break;
            }

        }
    }

    private void numberClickElementary(int id) {
        //「初級」のときのボタン処理
        switch (id) {
            case R.id.button0:
                //「最初が0でない、かつ"-"でない」なら押せる。
                if (!strMyAnswer.equals("0") && !strMyAnswer.equals("-")) {
                    strMyAnswer = strMyAnswer + "0";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button1:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "1";
                } else {
                    strMyAnswer = strMyAnswer + "1";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button2:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "2";
                } else {
                    strMyAnswer = strMyAnswer + "2";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button3:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "3";
                } else {
                    strMyAnswer = strMyAnswer + "3";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button4:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "4";
                } else {
                    strMyAnswer = strMyAnswer + "4";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button5:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "5";
                } else {
                    strMyAnswer = strMyAnswer + "5";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button6:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "6";
                } else {
                    strMyAnswer = strMyAnswer + "6";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button7:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "7";
                } else {
                    strMyAnswer = strMyAnswer + "7";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button8:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "8";
                } else {
                    strMyAnswer = strMyAnswer + "8";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button9:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "9";
                } else {
                    strMyAnswer = strMyAnswer + "9";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.buttonMinus:
                if (strMyAnswer.equals("") || strMyAnswer == null) {
                    strMyAnswer = "-";
                }

                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.buttonC:
                strMyAnswer = "";
                textViewAnswer.setText(strMyAnswer);
                break;
        }

    }

    private void numberClickMiddle(int id) {
        //「中級」のときのボタン処理
        switch (id) {
            case R.id.button0:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (!strMyAnswerLeft.equals("0") && !strMyAnswerLeft.equals("-")) {
                            strMyAnswerLeft = strMyAnswerLeft + "0";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (!strMyAnswerRight.equals("0") && !strMyAnswerRight.equals("-")) {
                            strMyAnswerRight = strMyAnswerRight + "0";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (!strMyAnswer.equals("0") && !strMyAnswer.equals("-")) {
                            strMyAnswer = strMyAnswer + "0";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button1:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "1";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "1";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "1";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "1";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "1";
                        } else {
                            strMyAnswer = strMyAnswer+ "1";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button2:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "2";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "2";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "2";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "2";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "2";
                        } else {
                            strMyAnswer = strMyAnswer + "2";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button3:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "3";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "3";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "3";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "3";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "3";
                        } else {
                            strMyAnswer = strMyAnswer + "3";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button4:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "4";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "4";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "4";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "4";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "4";
                        } else {
                            strMyAnswer = strMyAnswer + "4";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button5:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "5";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "5";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "5";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "5";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "5";
                        } else {
                            strMyAnswer = strMyAnswer + "5";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button6:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "6";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "6";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "6";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "6";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "6";
                        } else {
                            strMyAnswer = strMyAnswer + "6";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button7:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "7";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "7";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "7";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "7";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "7";
                        } else {
                            strMyAnswer = strMyAnswer + "7";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button8:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "8";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "8";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "8";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "8";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "8";
                        } else {
                            strMyAnswer = strMyAnswer + "8";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button9:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "9";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "9";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "9";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "9";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "9";
                        } else {
                            strMyAnswer = strMyAnswer + "9";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.buttonMinus:

                switch (questionPattern3) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("") || strMyAnswerLeft == null) {
                            strMyAnswerLeft = "-";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「右」
                        if (strMyAnswerRight.equals("") || strMyAnswerRight == null) {
                            strMyAnswerRight = "-";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 3:  //「右辺」
                        if (strMyAnswer.equals("") || strMyAnswer == null) {
                            strMyAnswer = "-";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;
                }
                break;

            case R.id.buttonC:

                switch (questionPattern3) {
                    case 1:
                        strMyAnswerLeft = "";
                        textViewLeft.setText(strMyAnswerLeft);
                        break;
                    case 2:
                        strMyAnswerRight = "";
                        textViewRight.setText(strMyAnswerRight);
                        break;
                    case 3:
                        strMyAnswer = "";
                        textViewAnswer.setText(strMyAnswer);
                        break;
                }
                break;

        }
    }

    private void numberClickAdvance(int id) {
        //「上級」のときのボタン処理
        switch (id) {
            case R.id.button0:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (!strMyAnswerLeft.equals("0") && !strMyAnswerLeft.equals("-")) {
                            strMyAnswerLeft = strMyAnswerLeft + "0";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (!strMyAnswerOperator.equals("0") && !strMyAnswerOperator.equals("-")) {
                            strMyAnswerOperator = strMyAnswerOperator + "0";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (!strMyAnswerRight.equals("0") && !strMyAnswerRight.equals("-")) {
                            strMyAnswerRight = strMyAnswerRight + "0";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (!strMyAnswer.equals("0") && !strMyAnswer.equals("-")) {
                            strMyAnswer = strMyAnswer + "0";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button1:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "1";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "1";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("0")) {
                            strMyAnswerOperator = "1";
                        } else {
                            strMyAnswerOperator = strMyAnswerOperator + "1";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "1";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "1";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "1";
                        } else {
                            strMyAnswer = strMyAnswer+ "1";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button2:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "2";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "2";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("0")) {
                            strMyAnswerOperator = "2";
                        } else {
                            strMyAnswerOperator = strMyAnswerOperator + "2";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "2";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "2";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "2";
                        } else {
                            strMyAnswer = strMyAnswer + "2";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button3:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "3";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "3";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("0")) {
                            strMyAnswerOperator = "3";
                        } else {
                            strMyAnswerOperator = strMyAnswerOperator + "3";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "3";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "3";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "3";
                        } else {
                            strMyAnswer = strMyAnswer + "3";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button4:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "4";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "4";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("0")) {
                            strMyAnswerOperator = "4";
                        } else {
                            strMyAnswerOperator = strMyAnswerOperator + "4";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "4";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "4";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "4";
                        } else {
                            strMyAnswer = strMyAnswer + "4";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button5:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "5";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "5";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("0")) {
                            strMyAnswerOperator = "5";
                        } else {
                            strMyAnswerOperator = strMyAnswerOperator + "5";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "5";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "5";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "5";
                        } else {
                            strMyAnswer = strMyAnswer + "5";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button6:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "6";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "6";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("0")) {
                            strMyAnswerOperator = "6";
                        } else {
                            strMyAnswerOperator = strMyAnswerOperator + "6";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "6";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "6";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "6";
                        } else {
                            strMyAnswer = strMyAnswer + "6";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button7:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "7";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "7";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("0")) {
                            strMyAnswerOperator = "7";
                        } else {
                            strMyAnswerOperator = strMyAnswerOperator + "7";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "7";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "7";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "7";
                        } else {
                            strMyAnswer = strMyAnswer + "7";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button8:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "8";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "8";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("0")) {
                            strMyAnswerOperator = "8";
                        } else {
                            strMyAnswerOperator = strMyAnswerOperator + "8";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "8";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "8";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "8";
                        } else {
                            strMyAnswer = strMyAnswer + "8";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.button9:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("0")) {
                            strMyAnswerLeft = "9";
                        } else {
                            strMyAnswerLeft = strMyAnswerLeft + "9";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("0")) {
                            strMyAnswerOperator = "9";
                        } else {
                            strMyAnswerOperator = strMyAnswerOperator + "9";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("0")) {
                            strMyAnswerRight = "9";
                        } else {
                            strMyAnswerRight = strMyAnswerRight + "9";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("0")) {
                            strMyAnswer = "9";
                        } else {
                            strMyAnswer = strMyAnswer + "9";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;

                }
                break;

            case R.id.buttonMinus:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("") || strMyAnswerLeft == null) {
                            strMyAnswerLeft = "-";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("") || strMyAnswerOperator == null) {
                            strMyAnswerOperator = "-";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("") || strMyAnswerRight == null) {
                            strMyAnswerRight = "-";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("") || strMyAnswer == null) {
                            strMyAnswer = "-";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;
                }
                break;

            case R.id.buttonC:

                switch (questionPattern4) {
                    case 1:
                        strMyAnswerLeft = "";
                        textViewLeft.setText(strMyAnswerLeft);
                        break;
                    case 2:
                        strMyAnswerOperator = "";
                        textViewOperator.setText(strMyAnswerOperator);
                        break;
                    case 3:
                        strMyAnswerRight = "";
                        textViewRight.setText(strMyAnswerRight);
                        break;
                    case 4:
                        strMyAnswer = "";
                        textViewAnswer.setText(strMyAnswer);
                        break;
                }
                break;

            case R.id.buttonDiv:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("") || strMyAnswerLeft == null) {
                            strMyAnswerLeft = "÷";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("") || strMyAnswerOperator == null) {
                            strMyAnswerOperator = "÷";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("") || strMyAnswerRight == null) {
                            strMyAnswerRight = "÷";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("") || strMyAnswer == null) {
                            strMyAnswer = "÷";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;
                }
                break;

            case R.id.buttonMul:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("") || strMyAnswerLeft == null) {
                            strMyAnswerLeft = "×";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("") || strMyAnswerOperator == null) {
                            strMyAnswerOperator = "×";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("") || strMyAnswerRight == null) {
                            strMyAnswerRight = "×";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("") || strMyAnswer == null) {
                            strMyAnswer = "×";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;
                }
                break;

            case R.id.buttonSub:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("") || strMyAnswerLeft == null) {
                            strMyAnswerLeft = "－";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("") || strMyAnswerOperator == null) {
                            strMyAnswerOperator = "－";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("") || strMyAnswerRight == null) {
                            strMyAnswerRight = "－";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("") || strMyAnswer == null) {
                            strMyAnswer = "－";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;
                }
                break;

            case R.id.buttonAdd:

                switch (questionPattern4) {
                    case 1:  //「左」
                        if (strMyAnswerLeft.equals("") || strMyAnswerLeft == null) {
                            strMyAnswerLeft = "＋";
                        }
                        textViewLeft.setText(strMyAnswerLeft);
                        break;

                    case 2:  //「符号」
                        if (strMyAnswerOperator.equals("") || strMyAnswerOperator == null) {
                            strMyAnswerOperator = "＋";
                        }
                        textViewOperator.setText(strMyAnswerOperator);
                        break;

                    case 3:  //「右」
                        if (strMyAnswerRight.equals("") || strMyAnswerRight == null) {
                            strMyAnswerRight = "＋";
                        }
                        textViewRight.setText(strMyAnswerRight);
                        break;

                    case 4:  //「右辺」
                        if (strMyAnswer.equals("") || strMyAnswer == null) {
                            strMyAnswer = "＋";
                        }
                        textViewAnswer.setText(strMyAnswer);
                        break;
                }
                break;

        }
    }

    public void answerCheckElementary() {
        //「初級」の答え合わせ
        buttonBack.setEnabled(false);
        button0.setEnabled(false);
        button1.setEnabled(false);
        button2.setEnabled(false);
        button3.setEnabled(false);
        button4.setEnabled(false);
        button5.setEnabled(false);
        button6.setEnabled(false);
        button7.setEnabled(false);
        button8.setEnabled(false);
        button9.setEnabled(false);
        buttonMinus.setEnabled(false);
        buttonC.setEnabled(false);
        buttonDiv.setEnabled(false);
        buttonMul.setEnabled(false);
        buttonSub.setEnabled(false);
        buttonAdd.setEnabled(false);
        buttonAnswerCheck.setEnabled(false);

        imageViewAnswerCheck.setVisibility(View.VISIBLE);


        //自分の答え
        myAnswer = Integer.parseInt(String.valueOf(textViewAnswer.getText()));

        //正解
        switch (questionOperator) {
            case 1:
                correctAnswer = questionLeft + questionRight;
                break;
            case 2:
                correctAnswer = questionLeft - questionRight;
                break;
        }


        if (myAnswer == correctAnswer) {
            imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

            numberOfCorrect += 1;
            textViewCorrect.setText(String.valueOf(numberOfCorrect));

            soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

        } else {
            imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
            soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
        }

        //「残り問題数」が1ずつ減る
        numberOfRemain -= 1;
        textViewRemain.setText(String.valueOf(numberOfRemain));

        //正答率の計算と表示
        numberOfPercent = (int) ((double) numberOfCorrect / (double) (selectQuestion - numberOfRemain) * 100);
        textViewPercent.setText(String.valueOf(numberOfPercent));


        if (numberOfRemain == 0) {
            buttonBack.setEnabled(true);

            textViewLastMessage.setText("テスト終了！");


            if (numberOfPercent == 100) {
                textViewComment.setText("天才！！");

            } else if (numberOfPercent >= 80) {
                textViewComment.setText("すごすぎ！！");

            } else if (numberOfPercent >= 60) {
                textViewComment.setText("やったね♪");

            } else if (numberOfPercent >= 50) {
                textViewComment.setText("頑張りました！");

            } else {
                textViewComment.setText("次も頑張ろう！");

            }
            timer.cancel();

        } else {
            //まだ問題数があるとき、タイマー処理で出題する
            TimerTask timerTask = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            elementaryQuestion();
                        }
                    });
                }
            };
            timer.schedule(timerTask, 1000);

        }
    }

    private void answerCheckMiddle() {
        //「中級」の答え合わせ
        buttonBack.setEnabled(false);
        button0.setEnabled(false);
        button1.setEnabled(false);
        button2.setEnabled(false);
        button3.setEnabled(false);
        button4.setEnabled(false);
        button5.setEnabled(false);
        button6.setEnabled(false);
        button7.setEnabled(false);
        button8.setEnabled(false);
        button9.setEnabled(false);
        buttonMinus.setEnabled(false);
        buttonC.setEnabled(false);
        buttonDiv.setEnabled(false);
        buttonMul.setEnabled(false);
        buttonSub.setEnabled(false);
        buttonAdd.setEnabled(false);
        buttonAnswerCheck.setEnabled(false);

        imageViewAnswerCheck.setVisibility(View.VISIBLE);

        //空欄の場所で、解答を場合分け
        switch (questionPattern3) {
            case 1:  //「左」を解答する
                //自分の答え
                myAnswerLeft = Integer.parseInt(String.valueOf(textViewLeft.getText()));

                //正解
                switch (questionOperator) {
                    case 1:  //＋のとき
                        correctAnswerLeft = questionAnswer - questionRight;
                        break;
                    case 2:
                        correctAnswerLeft = questionAnswer + questionRight;
                        break;
                    case 3:
                        correctAnswerLeft = questionAnswer / questionRight;
                        break;
                    case 4:
                        correctAnswerLeft = questionAnswer * questionRight;
                        break;
                }

                //自分の解答と正解を比較
                if (myAnswerLeft == correctAnswerLeft) {
                    imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

                    numberOfCorrect += 1;
                    textViewCorrect.setText(String.valueOf(numberOfCorrect));

                    soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

                } else {
                    imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
                    soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
                }
                break;

            case 2:  //「右」を解答する
                //自分の答え
                myAnswerRight = Integer.parseInt(String.valueOf(textViewRight.getText()));

                //正解
                switch (questionOperator) {
                    case 1:  //＋のとき
                        correctAnswerRight = questionAnswer - questionLeft;
                        break;
                    case 2:  //－のとき
                        correctAnswerRight = questionLeft - questionAnswer;
                        break;
                    case 3:  //×のとき
                        correctAnswerRight = questionAnswer / questionLeft;
                        break;
                    case 4:  //÷のとき
                        correctAnswerRight = questionLeft / questionAnswer;
                        break;
                }

                //自分の解答と正解を比較
                if (myAnswerRight == correctAnswerRight) {
                    imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

                    numberOfCorrect += 1;
                    textViewCorrect.setText(String.valueOf(numberOfCorrect));

                    soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

                } else {
                    imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
                    soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
                }
                break;

            case 3:  //「右辺」を解答する
                //自分の答え
                myAnswer = Integer.parseInt(String.valueOf(textViewAnswer.getText()));

                //正解
                switch (questionOperator) {
                    case 1:
                        correctAnswer = questionLeft + questionRight;
                        break;
                    case 2:
                        correctAnswer = questionLeft - questionRight;
                        break;
                    case 3:
                        correctAnswer = questionLeft * questionRight;
                        break;
                    case 4:
                        correctAnswer = questionLeft / questionRight;
                        break;
                }

                //自分の解答と正解を比較
                if (myAnswer == correctAnswer) {
                    imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

                    numberOfCorrect += 1;
                    textViewCorrect.setText(String.valueOf(numberOfCorrect));

                    soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

                } else {
                    imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
                    soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
                }
                break;
        }

        //「残り問題数」が1ずつ減る
        numberOfRemain -= 1;
        textViewRemain.setText(String.valueOf(numberOfRemain));

        //正答率の計算と表示
        numberOfPercent = (int) ((double) numberOfCorrect / (double) (selectQuestion - numberOfRemain) * 100);
        textViewPercent.setText(String.valueOf(numberOfPercent));


        if (numberOfRemain == 0) {
            buttonBack.setEnabled(true);

            textViewLastMessage.setText("テスト終了！");


            if (numberOfPercent == 100) {
                textViewComment.setText("天才！！");

            } else if (numberOfPercent >= 80) {
                textViewComment.setText("すごすぎ！！");

            } else if (numberOfPercent >= 60) {
                textViewComment.setText("やったね♪");

            } else if (numberOfPercent >= 50) {
                textViewComment.setText("頑張りました！");

            } else {
                textViewComment.setText("次も頑張ろう！");
            }


            timer.cancel();

        } else {
            //まだ問題数があるとき、タイマー処理で出題する
            TimerTask timerTask = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //出題4パターン「左」「符号」「右」「右辺」
                            questionPattern3 = random.nextInt(3) + 1;
                            middleQuestion();
                        }
                    });
                }
            };
            timer.schedule(timerTask, 1000);

        }

    }

    private void answerCheckAdvance() {
        //「上級」の答え合わせ
        buttonBack.setEnabled(false);
        button0.setEnabled(false);
        button1.setEnabled(false);
        button2.setEnabled(false);
        button3.setEnabled(false);
        button4.setEnabled(false);
        button5.setEnabled(false);
        button6.setEnabled(false);
        button7.setEnabled(false);
        button8.setEnabled(false);
        button9.setEnabled(false);
        buttonMinus.setEnabled(false);
        buttonC.setEnabled(false);
        buttonDiv.setEnabled(false);
        buttonMul.setEnabled(false);
        buttonSub.setEnabled(false);
        buttonAdd.setEnabled(false);
        buttonAnswerCheck.setEnabled(false);

        imageViewAnswerCheck.setVisibility(View.VISIBLE);

        //空欄の場所で、解答を場合分け
        switch (questionPattern4) {
            case 1:  //「左」を解答する
                //自分の答え
                myAnswerLeft = Integer.parseInt(String.valueOf(textViewLeft.getText()));

                //正解
                switch (questionOperator) {
                    case 1:  //＋のとき
                        correctAnswerLeft = questionAnswer - questionRight;
                        break;
                    case 2:
                        correctAnswerLeft = questionAnswer + questionRight;
                        break;
                    case 3:
                        correctAnswerLeft = questionAnswer / questionRight;
                        break;
                    case 4:
                        correctAnswerLeft = questionAnswer * questionRight;
                        break;
                }

                //自分の解答と正解を比較
                if (myAnswerLeft == correctAnswerLeft) {
                    imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

                    numberOfCorrect += 1;
                    textViewCorrect.setText(String.valueOf(numberOfCorrect));

                    soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

                } else {
                    imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
                    soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
                }
                break;

            case 2:  //「符号」を解答する
                //自分の答え
                strMyAnswerOperator = (String) textViewOperator.getText();

                //正解
                switch (strMyAnswerOperator) {
                    case "＋":  //＋
                        correctLeft = questionLeft + questionRight;
                        break;
                    case "－":  //－
                        correctLeft = questionLeft - questionRight;
                        break;
                    case "×":  //×
                        correctLeft = questionLeft * questionRight;
                        break;
                    case "÷":  //÷
                        correctLeft = questionLeft / questionRight;
                        break;
                }

                //「符号」:自分の入力した符号で、両辺が成立すれば〇、しなければ×
                if (strMyAnswerOperator.equals("＋")) {  //＋を入力したとき
                    if (correctLeft == questionAnswer) {
                        imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

                        numberOfCorrect += 1;
                        textViewCorrect.setText(String.valueOf(numberOfCorrect));

                        soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

                    } else {
                        imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
                        soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
                    }

                } else if (strMyAnswerOperator.equals("－")) {  //－を入力したとき
                    if (correctLeft == questionAnswer) {
                        imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

                        numberOfCorrect += 1;
                        textViewCorrect.setText(String.valueOf(numberOfCorrect));

                        soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

                    } else {
                        imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
                        soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
                    }

                } else if (strMyAnswerOperator.equals("×")) {  //×を入力したとき
                    if (correctLeft == questionAnswer) {
                        imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

                        numberOfCorrect += 1;
                        textViewCorrect.setText(String.valueOf(numberOfCorrect));

                        soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

                    } else {
                        imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
                        soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
                    }

                } else if (strMyAnswerOperator.equals("÷")){  //÷// を入力したとき
                    if (correctLeft == questionAnswer) {
                        imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

                        numberOfCorrect += 1;
                        textViewCorrect.setText(String.valueOf(numberOfCorrect));

                        soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

                    } else {
                        imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
                        soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
                    }
                }

                break;

            case 3:  //「右」を解答する  //TODO 符号を入力するとエラーが出る
                //自分の答え
                myAnswerRight = Integer.parseInt(String.valueOf(textViewRight.getText()));

                //正解
                switch (questionOperator) {
                    case 1:  //＋のとき
                        correctAnswerRight = questionAnswer - questionLeft;
                        break;
                    case 2:
                        correctAnswerRight = questionLeft - questionAnswer;
                        break;
                    case 3:
                        correctAnswerRight = questionAnswer / questionLeft;
                        break;
                    case 4:
                        correctAnswerRight = questionLeft * questionAnswer;
                        break;
                }

                //自分の解答と正解を比較
                if (myAnswerRight == correctAnswerRight) {
                    imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

                    numberOfCorrect += 1;
                    textViewCorrect.setText(String.valueOf(numberOfCorrect));

                    soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

                } else {
                    imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
                    soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
                }
                break;

            case 4:  //「右辺」を解答する
                //自分の答え
                myAnswer = Integer.parseInt(String.valueOf(textViewAnswer.getText()));

                //正解
                switch (questionOperator) {
                    case 1:
                        correctAnswer = questionLeft + questionRight;
                        break;
                    case 2:
                        correctAnswer = questionLeft - questionRight;
                        break;
                    case 3:
                        correctAnswer = questionLeft * questionRight;
                        break;
                    case 4:
                        correctAnswer = questionLeft / questionRight;
                        break;
                }

                //自分の解答と正解を比較
                if (myAnswer == correctAnswer) {
                    imageViewAnswerCheck.setImageResource(R.drawable.maru699403);

                    numberOfCorrect += 1;
                    textViewCorrect.setText(String.valueOf(numberOfCorrect));

                    soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

                } else {
                    imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
                    soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
                }
                break;
        }

        //「残り問題数」が1ずつ減る
        numberOfRemain -= 1;
        textViewRemain.setText(String.valueOf(numberOfRemain));

        //正答率の計算と表示
        numberOfPercent = (int) ((double) numberOfCorrect / (double) (selectQuestion - numberOfRemain) * 100);
        textViewPercent.setText(String.valueOf(numberOfPercent));


        if (numberOfRemain == 0) {
            buttonBack.setEnabled(true);

            textViewLastMessage.setText("テスト終了！");


            if (numberOfPercent == 100) {
                textViewComment.setText("天才！！");

            } else if (numberOfPercent >= 80) {
                textViewComment.setText("すごすぎ！！");

            } else if (numberOfPercent >= 60) {
                textViewComment.setText("やったね♪");

            } else if (numberOfPercent >= 50) {
                textViewComment.setText("頑張りました！");

            } else {
                textViewComment.setText("次も頑張ろう！");
            }


            timer.cancel();

        } else {
            //まだ問題数があるとき、タイマー処理で出題する
            TimerTask timerTask = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            //出題4パターン「左」「符号」「右」「右辺」
                            questionPattern4 = random.nextInt(4) + 1;
                            advanceQuestion();
                        }
                    });
                }
            };
            timer.schedule(timerTask, 1000);

        }

    }

    private void back() {
        finish();
    }

}
