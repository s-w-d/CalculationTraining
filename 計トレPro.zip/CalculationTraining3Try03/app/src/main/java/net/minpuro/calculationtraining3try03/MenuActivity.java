package net.minpuro.calculationtraining3try03;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

public class MenuActivity extends AppCompatActivity implements View.OnClickListener {

    Button buttonStart;  //「スタート」
    Spinner spinnerLevel, spinnerQuestion;

    ArrayAdapter<String> arrayAdapterLevel;  //レベルのスピナー
    ArrayAdapter<Integer> arrayAdapterQuestion;  //問題数のスピナー

    int selectQuestion;
    String questionLevel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        buttonStart = findViewById(R.id.buttonStart);
        spinnerLevel = findViewById(R.id.spinnerLevel);
        spinnerQuestion = findViewById(R.id.spinnerQuestion);

        arrayAdapterLevel = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item);
        arrayAdapterLevel.add("初級");
        arrayAdapterLevel.add("中級");
        arrayAdapterLevel.add("上級");
        spinnerLevel.setAdapter(arrayAdapterLevel);


        arrayAdapterQuestion = new ArrayAdapter<Integer>(this, android.R.layout.simple_spinner_item);
        arrayAdapterQuestion.add(5);
        arrayAdapterQuestion.add(10);
        arrayAdapterQuestion.add(20);
        spinnerQuestion.setAdapter(arrayAdapterQuestion);


        buttonStart.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        questionLevel = (String) spinnerLevel.getSelectedItem();
        selectQuestion = (int) spinnerQuestion.getSelectedItem();

        Intent intent = new Intent(MenuActivity.this, MainActivity.class);
        intent.putExtra("keyLevel", questionLevel);
        intent.putExtra("keySelect", selectQuestion);
        startActivity(intent);

    }
}
