package net.minpuro.calculationtraining3try02;

import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView textViewRemain;
    TextView textViewNumberOfCorrect;
    TextView textViewPercent;

    TextView textViewLeft, textViewOperator, textViewRight, textViewAnswer;

    Button button0, button1, button2, button3, button4, button5,
            button6, button7, button8, button9, buttonMinus, buttonC;

    Button buttonAnswerCheck, buttonBack;
    ImageView imageViewAnswerCheck;
    TextView textViewLM;  //「テスト終了」

    int id;
    int selectOfQuestion;
    int numberOfRemain;  //残り問題数
    Random random;
    int questionOperator;  //符号
    int questionLeft, questionRight;  //左辺と右辺
    int myAnswer;  //自分の答え
    String strMyAnswer;  //入力した答え
    int correctAnswer;  //正解
    int numberOfCorrect;  //正解数
    int numberOfPercent;  //正答率
    SoundPool soundPool;
    int soundCorrect, soundIncorrect;  //正解不正解の音
    Timer timer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewRemain = findViewById(R.id.textViewRemain);
        textViewNumberOfCorrect = findViewById(R.id.textViewNumberOfCorrect);
        textViewPercent = findViewById(R.id.textViewPercent);

        textViewLeft = findViewById(R.id.textViewLeft);
        textViewOperator = findViewById(R.id.textViewOperator);
        textViewRight = findViewById(R.id.textViewRight);
        textViewAnswer = findViewById(R.id.textViewAnswer);

        button0 = findViewById(R.id.button0);
        button1 = findViewById(R.id.button1);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        button5 = findViewById(R.id.button5);
        button6 = findViewById(R.id.button6);
        button7 = findViewById(R.id.button7);
        button8 = findViewById(R.id.button8);
        button9 = findViewById(R.id.button9);
        buttonMinus = findViewById(R.id.buttonMinus);
        buttonC = findViewById(R.id.buttonC);

        buttonAnswerCheck = findViewById(R.id.buttonAnswerCheck);
        buttonBack = findViewById(R.id.buttonBack);

        imageViewAnswerCheck = findViewById(R.id.imageViewAnswerCheck);
        textViewLM = findViewById(R.id.textVietextViewLastMessagewLastMessege);  //自動の候補にでてきたもの


        button0.setOnClickListener(this);
        button1.setOnClickListener(this);
        button2.setOnClickListener(this);
        button3.setOnClickListener(this);
        button4.setOnClickListener(this);
        button5.setOnClickListener(this);
        button6.setOnClickListener(this);
        button7.setOnClickListener(this);
        button8.setOnClickListener(this);
        button9.setOnClickListener(this);
        buttonMinus.setOnClickListener(this);
        buttonC.setOnClickListener(this);
        buttonAnswerCheck.setOnClickListener(this);
        buttonBack.setOnClickListener(this);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        selectOfQuestion = bundle.getInt("key");

        numberOfRemain = selectOfQuestion;
        textViewRemain.setText(String.valueOf(numberOfRemain));

        question();

    }

    @Override
    public void onResume() {
        super.onResume();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            soundPool = new SoundPool.Builder()
                    .setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .build())
                    .setMaxStreams(1)
                    .build();
        } else {
            soundPool = new SoundPool(1, AudioManager.STREAM_MUSIC, 0);
        }

        soundCorrect = soundPool.load(this, R.raw.sound_correct, 1);
        soundIncorrect = soundPool.load(this, R.raw.sound_incorrect, 1);

        timer = new Timer();

    }

    @Override
    public void onPause() {
        super.onPause();
        soundPool.release();
    }

    @Override
    public void onClick(View v) {

        id = v.getId();

        switch (id) {
            case R.id.buttonAnswerCheck:
                if (!strMyAnswer.equals("") && strMyAnswer != null) {
                    answerCheck();
                }
                break;
            case R.id.buttonBack:
                back();
                break;
            default:
                numberClick(id);
                break;
        }

    }

    private void numberClick(int id) {
        switch (id) {
            case R.id.button0:
                if (!strMyAnswer.equals("0") && !strMyAnswer.equals("-")) {
                    strMyAnswer = strMyAnswer + "0";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button1:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "1";
                } else {
                    strMyAnswer = strMyAnswer + "1";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button2:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "2";
                } else {
                    strMyAnswer = strMyAnswer + "2";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button3:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "3";
                } else {
                    strMyAnswer = strMyAnswer + "3";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button4:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "4";
                } else {
                    strMyAnswer = strMyAnswer + "4";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button5:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "5";
                } else {
                    strMyAnswer = strMyAnswer + "5";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button6:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "6";
                } else {
                    strMyAnswer = strMyAnswer + "6";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button7:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "7";
                } else {
                    strMyAnswer = strMyAnswer + "7";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button8:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "8";
                } else {
                    strMyAnswer = strMyAnswer + "8";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.button9:
                if (strMyAnswer.equals("0")) {
                    strMyAnswer = "9";
                } else {
                    strMyAnswer = strMyAnswer + "9";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.buttonMinus:
                if (strMyAnswer.equals("") || strMyAnswer == null) {
                    strMyAnswer = "-";
                }
                textViewAnswer.setText(strMyAnswer);
                break;

            case R.id.buttonC:
                strMyAnswer = "";
                textViewAnswer.setText(strMyAnswer);
                break;
        }

    }

    public void question() {
        button0.setEnabled(true);
        button1.setEnabled(true);
        button2.setEnabled(true);
        button3.setEnabled(true);
        button4.setEnabled(true);
        button5.setEnabled(true);
        button6.setEnabled(true);
        button7.setEnabled(true);
        button8.setEnabled(true);
        button9.setEnabled(true);
        buttonMinus.setEnabled(true);
        buttonC.setEnabled(true);
        buttonAnswerCheck.setEnabled(true);
        buttonBack.setEnabled(false);

        random = new Random();

        questionOperator = random.nextInt(4) + 1;

        switch (questionOperator) {
            case 1:
                textViewOperator.setText("+");
                questionLeft = random.nextInt(100) + 1;  //左辺(1～100)
                questionRight = random.nextInt(100) + 1;  //右辺(1～100)

                textViewLeft.setText(String.valueOf(questionLeft));
                textViewRight.setText(String.valueOf(questionRight));

                break;

            case 2:
                textViewOperator.setText("-");
                questionLeft = random.nextInt(100) + 1;  //左辺(1～100)
                questionRight = random.nextInt(100) + 1;  //右辺(1～100)

                textViewLeft.setText(String.valueOf(questionLeft));
                textViewRight.setText(String.valueOf(questionRight));

                break;

            case 3:
                textViewOperator.setText("×");
                questionLeft = random.nextInt(100) + 1;  //左辺(1～100)
                questionRight = random.nextInt(10) + 1;  //右辺(1～10)

                textViewLeft.setText(String.valueOf(questionLeft));
                textViewRight.setText(String.valueOf(questionRight));

                break;

            case 4:
                textViewOperator.setText("÷");

                questionRight = random.nextInt(10) + 1;
                textViewRight.setText(String.valueOf(questionRight));

                while (true) {
                    questionLeft = random.nextInt(999) + 1;

                    int division = questionLeft % questionRight;
                    if (division == 0) {
                        textViewLeft.setText(String.valueOf(questionLeft));
                        break;
                    }

                }

                break;
        }

        textViewAnswer.setText("");
        strMyAnswer = "";

        imageViewAnswerCheck.setVisibility(View.INVISIBLE);

    }

    public void answerCheck() {
        buttonBack.setEnabled(false);
        button0.setEnabled(false);
        button1.setEnabled(false);
        button2.setEnabled(false);
        button3.setEnabled(false);
        button4.setEnabled(false);
        button5.setEnabled(false);
        button6.setEnabled(false);
        button7.setEnabled(false);
        button8.setEnabled(false);
        button9.setEnabled(false);
        buttonMinus.setEnabled(false);
        buttonC.setEnabled(false);
        buttonAnswerCheck.setEnabled(false);

        imageViewAnswerCheck.setVisibility(View.VISIBLE);

        //自分の答え
        myAnswer = Integer.parseInt(String.valueOf(textViewAnswer.getText()));
        //正解
        switch (questionOperator) {
            case 1:
                correctAnswer = questionLeft + questionRight;
                break;
            case 2:
                correctAnswer = questionLeft - questionRight;
                break;
            case 3:
                correctAnswer = questionLeft * questionRight;
                break;
            case 4:
                correctAnswer = questionLeft / questionRight;
                break;
        }

        if (myAnswer == correctAnswer) {
            numberOfCorrect += 1;
            textViewNumberOfCorrect.setText(String.valueOf(numberOfCorrect));
            imageViewAnswerCheck.setImageResource(R.drawable.maru699403);
            soundPool.play(soundCorrect, 1.0f, 1.0f, 0, 0, 1.0f);

        } else {
            imageViewAnswerCheck.setImageResource(R.drawable.batsu699403);
            soundPool.play(soundIncorrect, 1.0f, 1.0f, 0, 0, 1.0f);
        }

        //「残り問題数」が1ずつ減る
        numberOfRemain -= 1;
        textViewRemain.setText(String.valueOf(numberOfRemain));

        //正答率の計算と表示
        numberOfPercent = (int) ((double) numberOfCorrect / (double) (selectOfQuestion - numberOfRemain) * 100);
        textViewPercent.setText(String.valueOf(numberOfPercent));


        if (numberOfRemain == 0) {
            buttonBack.setEnabled(true);

            textViewLM.setText("テスト終了！");
            timer.cancel();

        } else {
            //まだ問題数があるとき、タイマー処理で出題する
            TimerTask timerTask = new TimerTask() {
                @Override
                public void run() {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            question();
                        }
                    });
                }
            };
            timer.schedule(timerTask, 1000);
        }

    }

    public void back() {
        finish();
    }

}
